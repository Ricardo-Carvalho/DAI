
package BackEnd;


public class List_Assets {
    
    public List_Assets(){
        
    }
    
}
